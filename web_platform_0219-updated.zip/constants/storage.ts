export const STORAGE_KEY = {
  INVITE_CODE: 'invite_code',
  INVITE_TIPS_CLICK: 'invite_tips_click',
  INVITE_BTN_CLICK: 'invite_btn_click',
  SECRET_TOKEN: 'secret_token',
  SOCIAL_MEDIA_CLICK: 'social_media_click',
  GAMER_CLAIMED_MAP: 'gamer_claimed_map_01',
  DEV_EMAIL_SUBMIT: 'dev_email_submit',
  DEV_EMAIL_DAILY: 'dev_email_daily',
  COLLAB_FIRST_CLAIM_MAP: 'collab_first_claim_map',
  ACCESS_TOKENS: 'access_tokens',
};
