declare interface Window {
  ethereum?: Ethereum;
  bitkeep?: Ethereum;
  hpgButterfly?: any;
}
